import heapq
import time
import psutil

class State:
    def __init__(self, state, parent=None, depth=0):
        self.state = state
        self.parent = parent
        self.depth = depth

    def get_neighbors(self):
        neighbors = []
        for i in range(2, FlyingBlockPuzzle.num_of_pieces + 1):
            size = FlyingBlockPuzzle.size_of_pieces[i]

            for j in range(len(self.state[0])):
                is_empty0 = True
                is_empty1 = True
                z = 0
                while z < size:
                    if j + z < len(self.state[0]) and self.state[0][j + z] != 0 and self.state[0][j + z] != i:
                        is_empty0 = False
                    if j + z < len(self.state[0]) and self.state[1][j + z] != 0 and self.state[1][j + z] != i:
                        is_empty1 = False
                    if j + z >= len(self.state[0]):
                        break
                    if not is_empty0 and not is_empty1:
                        break
                    z += 1
                if is_empty0 and z == size:
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == i:
                            brd[0][k] = 0
                        if brd[1][k] == i:
                            brd[1][k] = 0
                    for z1 in range(size):
                        if j + z1 < len(self.state[0]):
                            brd[0][j + z1] = i
                    neighbors.append(State(brd))
                if is_empty1 and z == size:
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == i:
                            brd[0][k] = 0
                        if brd[1][k] == i:
                            brd[1][k] = 0
                    for z2 in range(size):
                        if j + z2 < len(self.state[0]):
                            brd[1][j + z2] = i
                    neighbors.append(State(brd))
                if size == 2 and (self.state[0][j] == 0 or self.state[0][j] == i) and (self.state[1][j] == 0 or self.state[1][j] == i) and not (self.state[1][j] == i and self.state[0][j] == i):
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == i:
                            brd[0][k] = 0
                        if brd[1][k] == i:
                            brd[1][k] = 0
                    brd[0][j] = i
                    brd[1][j] = i
                    neighbors.append(State(brd))
        if FlyingBlockPuzzle.size_of_pieces[1]==3:
            for i in range(len(self.state[0])):
                if (self.state[0][i] == 0 or self.state[0][i] == 1) and (self.state[1][i] == 0 or self.state[1][i] == 1):
                    if i + 1 < len(self.state[0]) and (self.state[0][i + 1] == 0 or self.state[0][i + 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[0][i + 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[0][i + 1] = 1
                            neighbors.append(State(brd))
                    if i + 1 < len(self.state[0]) and (self.state[1][i + 1] == 0 or self.state[1][i + 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[1][i + 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[1][i + 1] = 1
                            neighbors.append(State(brd))
                    if i - 1 >= 0 and (self.state[0][i - 1] == 0 or self.state[0][i - 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[0][i - 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[0][i - 1] = 1
                            neighbors.append(State(brd))
                    if i - 1 >= 0 and (self.state[1][i - 1] == 0 or self.state[1][i - 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[1][i - 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[1][i - 1] = 1
                            neighbors.append(State(brd))

        else:
            for i in range(len(self.state[0])-FlyingBlockPuzzle.height_of_semm_piece+1):
                is_exact_match=True
                not_same_exact=False
                is_mirror_match=True
                not_same_mirror=False
                z=0
                for j in range(i,i+FlyingBlockPuzzle.height_of_semm_piece):
                    if FlyingBlockPuzzle.mask[0][z]==1 and not(self.state[0][j] == 1 or self.state[0][j] == 0):
                        is_exact_match=False
                    if FlyingBlockPuzzle.mask[0][z]==1 and  self.state[0][j] == 0:
                        not_same_exact=True
                    if FlyingBlockPuzzle.mask[1][z]==1 and not(self.state[1][j] == 1 or self.state[1][j] == 0):
                        is_exact_match=False
                    if FlyingBlockPuzzle.mask[1][z]==1 and  self.state[1][j] == 0:
                        not_same_exact=True
                    

                    if FlyingBlockPuzzle.mask[0][z]==1 and not(self.state[1][j] == 1 or self.state[1][j] == 0):
                        is_mirror_match=False
                    if FlyingBlockPuzzle.mask[0][z]==1 and self.state[1][j] == 0:
                        not_same_mirror=True
                    if FlyingBlockPuzzle.mask[1][z]==1 and not(self.state[0][j] == 1 or self.state[0][j] == 0):
                        is_mirror_match=False
                    if FlyingBlockPuzzle.mask[1][z]==1 and  self.state[0][j] == 0:
                        not_same_mirror=True

                    z+=1

                if is_exact_match and not_same_exact:
                    
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == 1:
                            brd[0][k] = 0
                        if brd[1][k] == 1:
                            brd[1][k] = 0
                    
                    z=0
                    for j in range(i,i+FlyingBlockPuzzle.height_of_semm_piece):
                        if FlyingBlockPuzzle.mask[0][z]==1:
                            brd[0][j]=1
                        if FlyingBlockPuzzle.mask[1][z]==1:
                            brd[1][j]=1
                        z+=1

                    neighbors.append(State(brd))



                if is_mirror_match and not_same_mirror:
                    

                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == 1:
                            brd[0][k] = 0
                        if brd[1][k] == 1:
                            brd[1][k] = 0
                    
                    z=0
                    for j in range(i,i+FlyingBlockPuzzle.height_of_semm_piece):
                        if FlyingBlockPuzzle.mask[0][z]==1:
                            brd[1][j]=1
                        if FlyingBlockPuzzle.mask[1][z]==1:
                            brd[0][j]=1
                        z+=1

                    neighbors.append(State(brd))

        return neighbors

    def is_goal(self, goal):
        for i in range(len(goal[0])):
            if goal[0][i] != 0 and goal[0][i] != self.state[0][i]:
                return False
            if goal[1][i] != 0 and goal[1][i] != self.state[1][i]:
                return False
        return True

    def heuristic(self, goal):
        goal_non_zero_positions = [(i, j) for i in range(len(goal)) for j in range(len(goal[0])) if goal[i][j] != 0]
        current_non_zero_values = set()
        for (i, j) in goal_non_zero_positions:
            if self.state[i][j] != 0:
                current_non_zero_values.add(self.state[i][j])
        heuristic_value = len(current_non_zero_values)
        if not self.is_goal(goal):
            heuristic_value += 1
            
        return heuristic_value

    def __lt__(self, other):
        return (self.depth + self.heuristic(FlyingBlockPuzzle.goal)) < (other.depth + other.heuristic(FlyingBlockPuzzle.goal))

def print_solution(state, n):
    if state is None:
        return

    print_solution(state.parent, n)
    print()
    for i in range(n):
        print(state.state[0][i], state.state[1][i])

def check_memory_limit(limit_mb=10240):
    process = psutil.Process()
    memory_usage = process.memory_info().rss / (1024 ** 2) 
    if memory_usage > limit_mb:
        print(f"Memory limit exceeded: {memory_usage:.2f} MB used.")
        return True
    return False


def A_star(root, goal, n, memory_limit=10240):
    open_list = []
    heapq.heappush(open_list, (0, root))
    current_depth = -1
    s_open_nodes = 1
    num=FlyingBlockPuzzle.num
    while open_list:
        if check_memory_limit(memory_limit):
            raise MemoryError("Memory usage exceeded the limit.")
        
        _time = time.time()
        if(_time - FlyingBlockPuzzle.start_time > 1740):
            break
        _, state = heapq.heappop(open_list)
        FlyingBlockPuzzle.expanded_node_count+=1
        if state.depth > current_depth:
            print(f"searching in depth {state.depth}")
            current_depth = state.depth
            FlyingBlockPuzzle.depth_nodes[current_depth] = s_open_nodes
            s_open_nodes = 0
            
        if(state.depth in num.keys()):
            num[state.depth]+=1
        else:
            num[state.depth]=1
        if state.is_goal(goal):
            return state

        neighbors = state.get_neighbors()
        FlyingBlockPuzzle.opened_node_count+=len(neighbors)
        s_open_nodes += len(neighbors)
        
        for ng in neighbors:
            ng.parent = state
            ng.depth = state.depth + 1
            cost = ng.depth + ng.heuristic(goal)
            heapq.heappush(open_list, (cost, ng))
            
        FlyingBlockPuzzle.depth_nodes[current_depth + 1] = s_open_nodes

    return None

class FlyingBlockPuzzle:
    goal = []
    size_of_pieces = [-1]
    height_of_semm_piece = 0
    mask=[[],[]]
    num_of_pieces = 0
    expanded_node_count=1
    opened_node_count=1
    num=dict()
    start_time=0
    depth_nodes = {}
    @staticmethod
    def main():
        FlyingBlockPuzzle.num_of_pieces = 0
        num=FlyingBlockPuzzle.num
        
        n = int(input("enter the height of the frame(n): "))
        init_board = [[0] * n for _ in range(2)]
        FlyingBlockPuzzle.goal = [[0] * n for _ in range(2)]

        print("enter the frame:")
        size_of_semm=0
        for i in range(n):
            s1 = input()
            ind_space_s1 = s1.index(' ')
            init_board[0][i] = int(s1[0:ind_space_s1])
            init_board[1][i] = int(s1[ind_space_s1 + 1 :])
            if init_board[0][i] > FlyingBlockPuzzle.num_of_pieces:
                FlyingBlockPuzzle.num_of_pieces = init_board[0][i]
            if init_board[1][i] > FlyingBlockPuzzle.num_of_pieces:
                FlyingBlockPuzzle.num_of_pieces = init_board[1][i]

            if init_board[0][i]==1:
                size_of_semm+=1
            if init_board[1][i]==1:
                size_of_semm+=1
        FlyingBlockPuzzle.size_of_pieces.append(size_of_semm)

        print("enter the goal:")
        for i in range(n):
            s2 = input()
            ind_space_s2 = s2.index(' ')
            FlyingBlockPuzzle.goal[0][i] = int(s2[0:ind_space_s2])
            FlyingBlockPuzzle.goal[1][i] = int(s2[ind_space_s2 + 1:])

        for i in range(2, FlyingBlockPuzzle.num_of_pieces + 1):
            flag = False
            start_pos = -1
            for j in range(n):
                if init_board[0][j] == i:
                    flag = True
                    start_pos = j
                    break
            if flag:
                if init_board[1][start_pos] == i:
                    FlyingBlockPuzzle.size_of_pieces.append(2)
                else:
                    size = 1
                    while start_pos + size < n and init_board[0][start_pos + size] == i:
                        size += 1
                    FlyingBlockPuzzle.size_of_pieces.append(size)
            else:
                start_pos = -1
                for j in range(n):
                    if init_board[1][j] == i:
                        start_pos = j
                        break
                size = 1
                while start_pos + size < n and init_board[1][start_pos + size] == i:
                    size += 1
                FlyingBlockPuzzle.size_of_pieces.append(size)




        flag=False
        start_pos=-1
        for i in range(n):
            if init_board[0][i]==1 or init_board[1][i]==1:
                FlyingBlockPuzzle.height_of_semm_piece+=1
                if not flag:
                    flag=True
                    start_pos=i

        for i in range(FlyingBlockPuzzle.height_of_semm_piece):
            FlyingBlockPuzzle.mask[0].append(0)
            FlyingBlockPuzzle.mask[1].append(0)

        



        z=0
        for i in range(start_pos, start_pos+FlyingBlockPuzzle.height_of_semm_piece):
            if init_board[0][i]==1:
                FlyingBlockPuzzle.mask[0][z]=1
            else:
                FlyingBlockPuzzle.mask[0][z]=-1

            if init_board[1][i]==1:
                FlyingBlockPuzzle.mask[1][z]=1
            else:
                FlyingBlockPuzzle.mask[1][z]=-1

            z+=1

        root = State(init_board)
        root.depth = 0
        FlyingBlockPuzzle.start_time = time.time()
        try:
            goal_state = A_star(root, FlyingBlockPuzzle.goal, n, memory_limit=10240)
        except:
            print('memory limit')
            print('Opend nodes in each state:')
            print(FlyingBlockPuzzle.depth_nodes)
            print(f"Opened states: {FlyingBlockPuzzle.opened_node_count}")
        finally:
            end_time = time.time()
            for key, value in num.items() :
                    print (key, value)
            sum=0
            for key, value in num.items() :
                if key != 0:
                    print('average b in layer ',key,'=',value/num[key-1])
                    sum+=(value/num[key-1])
            if len(num.keys()) !=0:
                print('total average b is ', sum/len(num.keys()))
            if(goal_state!=None):
                print(f"the best solution is in depth: {goal_state.depth}")
                print("solution:")
                print_solution(goal_state, n)
            print(f"Search time: {end_time - FlyingBlockPuzzle.start_time} seconds")
            print(f"Expanded states: {FlyingBlockPuzzle.expanded_node_count}")
            print('Opend nodes in each state:')
            print(FlyingBlockPuzzle.depth_nodes)
            print(f"Opened states: {FlyingBlockPuzzle.opened_node_count}")
if __name__ == "__main__":
    FlyingBlockPuzzle.main()
