print('enter n:')
n = int(input())
print('enter d:')
d = int(input())
b= (n)**(1/(d+1))
scope=1
threshold=1
sign=0

while(True):
    
    n_=0
    for i in range(d+1):
        n_+= b**i
    dist= n - n_
    print(' b=',b,' dist=' ,abs(dist))
    if(abs(dist) < threshold):
        print(b)
        break

    elif(dist > 0):
        if sign==-1:
            scope/=2
        b=b+scope
        sign=1
       
    elif(dist<0):
        if sign==1:
            scope/=2
        sign=-1
        b=b-scope
        

    

