import heapq
from math import ceil, floor, log2
import time
import psutil

class State:
    def __init__(self, state, parent=None, depth=0):
        self.state = state
        self.parent = parent
        self.depth = depth
        
    def get_neighbors(self):
        neighbors = []
        for i in range(2, FlyingBlockPuzzle.num_of_pieces + 1):
            size = FlyingBlockPuzzle.size_of_pieces[i]

            for j in range(len(self.state[0])):
                is_empty0 = True
                is_empty1 = True
                z = 0
                while z < size:
                    if j + z < len(self.state[0]) and self.state[0][j + z] != 0 and self.state[0][j + z] != i:
                        is_empty0 = False
                    if j + z < len(self.state[0]) and self.state[1][j + z] != 0 and self.state[1][j + z] != i:
                        is_empty1 = False
                    if j + z >= len(self.state[0]):
                        break
                    if not is_empty0 and not is_empty1:
                        break
                    z += 1
                if is_empty0 and z == size:
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == i:
                            brd[0][k] = 0
                        if brd[1][k] == i:
                            brd[1][k] = 0
                    for z1 in range(size):
                        if j + z1 < len(self.state[0]):
                            brd[0][j + z1] = i
                    neighbors.append(State(brd))
                if is_empty1 and z == size:
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == i:
                            brd[0][k] = 0
                        if brd[1][k] == i:
                            brd[1][k] = 0
                    for z2 in range(size):
                        if j + z2 < len(self.state[0]):
                            brd[1][j + z2] = i
                    neighbors.append(State(brd))
                if size == 2 and (self.state[0][j] == 0 or self.state[0][j] == i) and (self.state[1][j] == 0 or self.state[1][j] == i) and not (self.state[1][j] == i and self.state[0][j] == i):
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == i:
                            brd[0][k] = 0
                        if brd[1][k] == i:
                            brd[1][k] = 0
                    brd[0][j] = i
                    brd[1][j] = i
                    neighbors.append(State(brd))
        if FlyingBlockPuzzle.size_of_pieces[1]==3:
            for i in range(len(self.state[0])):
                if (self.state[0][i] == 0 or self.state[0][i] == 1) and (self.state[1][i] == 0 or self.state[1][i] == 1):
                    if i + 1 < len(self.state[0]) and (self.state[0][i + 1] == 0 or self.state[0][i + 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[0][i + 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[0][i + 1] = 1
                            neighbors.append(State(brd))
                    if i + 1 < len(self.state[0]) and (self.state[1][i + 1] == 0 or self.state[1][i + 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[1][i + 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[1][i + 1] = 1
                            neighbors.append(State(brd))
                    if i - 1 >= 0 and (self.state[0][i - 1] == 0 or self.state[0][i - 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[0][i - 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[0][i - 1] = 1
                            neighbors.append(State(brd))
                    if i - 1 >= 0 and (self.state[1][i - 1] == 0 or self.state[1][i - 1] == 1):
                        if not (self.state[0][i] == 1 and self.state[1][i] == 1 and self.state[1][i - 1] == 1):
                            brd = [self.state[0][:], self.state[1][:]]
                            for k in range(len(self.state[0])):
                                if brd[0][k] == 1:
                                    brd[0][k] = 0
                                if brd[1][k] == 1:
                                    brd[1][k] = 0
                            brd[0][i] = 1
                            brd[1][i] = 1
                            brd[1][i - 1] = 1
                            neighbors.append(State(brd))

        else:
            for i in range(len(self.state[0])-FlyingBlockPuzzle.height_of_semm_piece+1):
                is_exact_match=True
                not_same_exact=False
                is_mirror_match=True
                not_same_mirror=False
                z=0
                for j in range(i,i+FlyingBlockPuzzle.height_of_semm_piece):
                    if FlyingBlockPuzzle.mask[0][z]==1 and not(self.state[0][j] == 1 or self.state[0][j] == 0):
                        is_exact_match=False
                    if FlyingBlockPuzzle.mask[0][z]==1 and  self.state[0][j] == 0:
                        not_same_exact=True
                    if FlyingBlockPuzzle.mask[1][z]==1 and not(self.state[1][j] == 1 or self.state[1][j] == 0):
                        is_exact_match=False
                    if FlyingBlockPuzzle.mask[1][z]==1 and  self.state[1][j] == 0:
                        not_same_exact=True
                    

                    if FlyingBlockPuzzle.mask[0][z]==1 and not(self.state[1][j] == 1 or self.state[1][j] == 0):
                        is_mirror_match=False
                    if FlyingBlockPuzzle.mask[0][z]==1 and self.state[1][j] == 0:
                        not_same_mirror=True
                    if FlyingBlockPuzzle.mask[1][z]==1 and not(self.state[0][j] == 1 or self.state[0][j] == 0):
                        is_mirror_match=False
                    if FlyingBlockPuzzle.mask[1][z]==1 and  self.state[0][j] == 0:
                        not_same_mirror=True

                    z+=1

                if is_exact_match and not_same_exact:
                    
                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == 1:
                            brd[0][k] = 0
                        if brd[1][k] == 1:
                            brd[1][k] = 0
                    
                    z=0
                    for j in range(i,i+FlyingBlockPuzzle.height_of_semm_piece):
                        if FlyingBlockPuzzle.mask[0][z]==1:
                            brd[0][j]=1
                        if FlyingBlockPuzzle.mask[1][z]==1:
                            brd[1][j]=1
                        z+=1

                    neighbors.append(State(brd))



                if is_mirror_match and not_same_mirror:
                    

                    brd = [self.state[0][:], self.state[1][:]]
                    for k in range(len(self.state[0])):
                        if brd[0][k] == 1:
                            brd[0][k] = 0
                        if brd[1][k] == 1:
                            brd[1][k] = 0
                    
                    z=0
                    for j in range(i,i+FlyingBlockPuzzle.height_of_semm_piece):
                        if FlyingBlockPuzzle.mask[0][z]==1:
                            brd[1][j]=1
                        if FlyingBlockPuzzle.mask[1][z]==1:
                            brd[0][j]=1
                        z+=1

                    neighbors.append(State(brd))

        return neighbors

    def is_goal(self, goal):
        for i in range(len(goal[0])):
            if goal[0][i] != 0 and goal[0][i] != self.state[0][i]:
                return False
            if goal[1][i] != 0 and goal[1][i] != self.state[1][i]:
                return False
        return True

    def heuristic1(self, goal):
        if FlyingBlockPuzzle.state_type == 'A':
            return self.h_A(goal)
        if FlyingBlockPuzzle.state_type == 'B':
            return self.h_B(goal)
        if FlyingBlockPuzzle.state_type == 'C':
            return self.h_C(goal)
        if FlyingBlockPuzzle.state_type == 'D':
            return self.h_D(goal)
        if FlyingBlockPuzzle.state_type == 'E':
            return self.h_E(goal)
        if FlyingBlockPuzzle.state_type == 'F':
            return self.h_F(goal)
        if FlyingBlockPuzzle.state_type == 'G':
            return self.h_G(goal)

    def h_A(self, goal):
        goal_non_zero_positions = [(i, j) for i in range(len(goal)) for j in range(len(goal[0])) if goal[i][j] != 0]
        current_non_zero_values = set()
        for (i, j) in goal_non_zero_positions:
            if self.state[i][j] != 0 and self.state[i][j] != goal[i][j]:
                current_non_zero_values.add(self.state[i][j])
        heuristic_value = len(current_non_zero_values)
        if not self.is_goal(goal):
            heuristic_value += 1
            
        return heuristic_value

    def h_B(self, goal):
        unpacked_state = self.state
        frame_column = next(i for i in range(len(unpacked_state[0])) if unpacked_state[0][i] == 1 and unpacked_state[1][i] == 1)
        goal_column = next(j for j in range(len(goal[0])) if goal[0][j] == 1 and goal[1][j] == 1)

        if frame_column < goal_column:
            columns_in_path = range(frame_column + 1, goal_column + 1)
        else:
            columns_in_path = range(goal_column, frame_column)

        
        pieces_with_size_1 = 0
        num_places_pieces_with_size_greater_1 = 0

        unique_pieces = set()
        for i in columns_in_path:
            if unpacked_state[0][i] not in unique_pieces and unpacked_state[0][i] != 0 and unpacked_state[0][i] != 1:
                if FlyingBlockPuzzle.size_of_pieces[unpacked_state[0][i]] > 1:
                    num_places_pieces_with_size_greater_1 += 1
                else:
                    pieces_with_size_1 += 1
                unique_pieces.add(unpacked_state[0][i])
            if unpacked_state[1][i] not in unique_pieces and unpacked_state[1][i] != 0 and unpacked_state[1][i] != 1:
                if FlyingBlockPuzzle.size_of_pieces[unpacked_state[1][i]] > 1:
                    num_places_pieces_with_size_greater_1 += 1
                else:
                    pieces_with_size_1 += 1
                unique_pieces.add(unpacked_state[1][i])

        vertical_distance = abs(frame_column - goal_column)

        if goal_column > frame_column :
            if frame_column + 2 < len(unpacked_state[0]) and pieces_with_size_1 > 0 and (unpacked_state[0][frame_column + 1]==1 or unpacked_state[1][frame_column + 1]==1):
                vertical_distance-=1
            
        elif goal_column < frame_column:
            if frame_column - 2 >= 0 and pieces_with_size_1 > 0 and (unpacked_state[0][frame_column - 1]==1 or unpacked_state[1][frame_column - 1]==1):
                vertical_distance-=1
            
        percent=0.5
        
        heuristic_value = vertical_distance + num_places_pieces_with_size_greater_1 
        return heuristic_value
        
            

        
    def h_C(self, goal):
        unpacked_state = self.state
        frame_column = next(i for i in range(len(unpacked_state[0])) if unpacked_state[0][i] == 1 and unpacked_state[1][i] == 1)
        goal_column = next(j for j in range(len(goal[0])) if goal[0][j] == 1 and goal[1][j] == 1)

        if frame_column < goal_column:
            columns_in_path = range(frame_column + 1, goal_column + 1)
        else:
            columns_in_path = range(goal_column, frame_column)

    
        pieces_with_size_1 = 0
        num_places_pieces_with_size_greater_1 = 0

        unique_pieces = set()
        for i in columns_in_path:
            if unpacked_state[0][i] not in unique_pieces and unpacked_state[0][i] != 0 and unpacked_state[0][i] != 1:
                if FlyingBlockPuzzle.size_of_pieces[unpacked_state[0][i]] > 1:
                    num_places_pieces_with_size_greater_1 += 1
                else:
                    pieces_with_size_1 += 1
                unique_pieces.add(unpacked_state[0][i])
            if unpacked_state[1][i] not in unique_pieces and unpacked_state[1][i] != 0 and unpacked_state[1][i] != 1:
                if FlyingBlockPuzzle.size_of_pieces[unpacked_state[1][i]] > 1:
                    num_places_pieces_with_size_greater_1 += 1
                else:
                    pieces_with_size_1 += 1
                unique_pieces.add(unpacked_state[1][i])

        vertical_distance = abs(frame_column - goal_column)

        percent=1
        if pieces_with_size_1 < 2:
            heuristic_value = vertical_distance + num_places_pieces_with_size_greater_1 + pieces_with_size_1
            return heuristic_value
        else:
            unique_pieces = set()
            for col in columns_in_path:
                if col < len(unpacked_state[0]):
                    if unpacked_state[0][col] != 0 and unpacked_state[0][col] != FlyingBlockPuzzle.goal_piece:
                        unique_pieces.add(unpacked_state[0][col])
                    if unpacked_state[1][col] != 0 and unpacked_state[1][col] != FlyingBlockPuzzle.goal_piece:
                        unique_pieces.add(unpacked_state[1][col])

            heuristic_value = vertical_distance + len(unique_pieces) - ceil((1-percent) * pieces_with_size_1)
            return heuristic_value

    def h_D(self, goal):
        h = 0
        goal_piece = next(piece for row in goal for piece in row if piece != 0)

        unpacked_state = self.state
        frame_topmost_index = None
        
        for i in range(len(unpacked_state[0])):
            if unpacked_state[0][i] == goal_piece or unpacked_state[1][i] == goal_piece:
                frame_topmost_index = i
                break
        size_of_piece = FlyingBlockPuzzle.size_of_pieces[goal_piece]
        

        goal_topmost_index = None
        for j in range(len(goal[0])):
            if goal[0][j] == goal_piece or goal[1][j] == goal_piece:
                goal_topmost_index = j
                break

        vertical_distance = abs(frame_topmost_index - goal_topmost_index)
        h = ceil(vertical_distance / FlyingBlockPuzzle.num_of_vacant)
        

        goal_side = 0 if goal[0][goal_topmost_index] == goal_piece else 1
        
        if frame_topmost_index < goal_topmost_index:
            columns_in_path = range(frame_topmost_index + 1, goal_topmost_index + size_of_piece)
        else:
            columns_in_path = range(goal_topmost_index, frame_topmost_index)
        
        unique_pieces = set()
        for col in columns_in_path:
            piece_in_path = unpacked_state[goal_side][col]
            if piece_in_path != 0 and piece_in_path != goal_piece and (piece_in_path not in unique_pieces):
                unique_pieces.add(piece_in_path)

        h += len(unique_pieces)
        
        return h


    def h_E(self, goal):
        unpacked_state = self.state
        frame_pos = [(i, j) for i in range(len(unpacked_state)) for j in range(len(unpacked_state[0])) if unpacked_state[i][j] == FlyingBlockPuzzle.goal_piece]
        

        goal_pos = [(i, j) for i in range(len(goal)) for j in range(len(goal[0])) if goal[i][j] == FlyingBlockPuzzle.goal_piece]

        frame_topmost_index = min(frame_pos, key=lambda x: x[1])[1]
        goal_topmost_index = min(goal_pos, key=lambda x: x[1])[1]
        frame_bottommost_index = max(frame_pos, key=lambda x: x[1])[1]
        goal_bottommost_index = max(goal_pos, key=lambda x: x[1])[1]
        frame_side = 0 if (unpacked_state[0][frame_topmost_index]==FlyingBlockPuzzle.goal_piece) else 1
        goal_side = 0 if (goal[0][goal_topmost_index]==FlyingBlockPuzzle.goal_piece) else 1
        is_frame_above_goal = frame_bottommost_index < goal_bottommost_index
        is_goal_above_frame = frame_topmost_index > goal_topmost_index
        is_horizontal_in_goal = (goal[0][goal_topmost_index] == FlyingBlockPuzzle.goal_piece and goal[1][goal_topmost_index] == FlyingBlockPuzzle.goal_piece)
        is_horizontal_in_frame = (unpacked_state[0][frame_topmost_index] == FlyingBlockPuzzle.goal_piece and unpacked_state[1][frame_topmost_index] == FlyingBlockPuzzle.goal_piece)
        is_in_other_side = (unpacked_state[0][frame_topmost_index] == FlyingBlockPuzzle.goal_piece and goal[1][goal_topmost_index] == FlyingBlockPuzzle.goal_piece and (not is_horizontal_in_frame) and (not is_horizontal_in_goal)) or \
                           (unpacked_state[1][frame_topmost_index] == FlyingBlockPuzzle.goal_piece and goal[0][goal_topmost_index] == FlyingBlockPuzzle.goal_piece and (not is_horizontal_in_frame) and (not is_horizontal_in_goal))

        if is_frame_above_goal:
            vertical_distance = abs(frame_bottommost_index - goal_bottommost_index)
        elif is_goal_above_frame:
            vertical_distance = abs(frame_topmost_index - goal_topmost_index)
        else:
            vertical_distance=0

        h =vertical_distance
        
        if is_in_other_side:
            h += 2

        if not (vertical_distance==0 and is_horizontal_in_frame) and (is_horizontal_in_goal):
            h += 1

        h*=2
        
        if is_frame_above_goal:
            if is_horizontal_in_goal and is_horizontal_in_frame:
                if frame_bottommost_index + 1 < len(unpacked_state[0]) and ((unpacked_state[0][frame_bottommost_index + 1] == 0) or (unpacked_state[1][frame_bottommost_index + 1] == 0)):
                    h -= 1
            elif is_horizontal_in_goal and not is_horizontal_in_frame:
                if frame_bottommost_index + 1 < len(unpacked_state[0]) and ((unpacked_state[frame_side][frame_bottommost_index + 1] == 0)):
                    h -= 1
            elif not is_horizontal_in_goal and is_horizontal_in_frame:
                if frame_bottommost_index + 1 < len(unpacked_state[0]) and (unpacked_state[goal_side][frame_bottommost_index + 1] == 0):
                    h -= 1
                    
            elif not is_horizontal_in_goal and not is_horizontal_in_frame:
                if frame_bottommost_index + 1 < len(unpacked_state[0]) and (unpacked_state[frame_side][frame_bottommost_index + 1] == 0):
                    h -= 1
                if is_in_other_side and unpacked_state[goal_side][frame_bottommost_index] == 0:
                    h -= 1

        elif is_goal_above_frame:
            if is_horizontal_in_goal and is_horizontal_in_frame:
                if frame_topmost_index - 1 >= 0 and ((unpacked_state[0][frame_topmost_index - 1] == 0) or (unpacked_state[1][frame_topmost_index - 1] == 0)):
                    h -= 1
            elif is_horizontal_in_goal and not is_horizontal_in_frame:
                if frame_topmost_index - 1 >= 0 and ((unpacked_state[frame_side][frame_topmost_index - 1] == 0)):
                    h -= 1
                   
            elif not is_horizontal_in_goal and is_horizontal_in_frame:
                if frame_topmost_index - 1 >= 0 and (unpacked_state[goal_side][frame_topmost_index - 1] == 0):
                    h -= 1
            elif not is_horizontal_in_goal and not is_horizontal_in_frame:
                if frame_topmost_index - 1 >= 0 and (unpacked_state[frame_side][frame_topmost_index - 1] == 0):
                    h -= 1
                if is_in_other_side and unpacked_state[goal_side][frame_topmost_index] == 0:
                    h -= 1

        elif vertical_distance==0:
            if not is_horizontal_in_goal and is_in_other_side:
                if  unpacked_state[goal_side][frame_topmost_index] == 0 or unpacked_state[goal_side][frame_bottommost_index] == 0:
                    h -= 1
            elif (is_horizontal_in_goal and not is_horizontal_in_frame):
                other_side= 0 if frame_side==1 else 1
                if unpacked_state[other_side][goal_topmost_index] == 0:
                    h-=1
                
        else:
            print('this must not happen') 
        
        if h<0:
            print('negetive heuristic')

       
        return h



    


    def h_F(self, goal):
        h = 0
        goal_piece = 1

        unpacked_state = self.state
        frame_topmost_index = None
        
        for i in range(len(unpacked_state[0])):
            if unpacked_state[0][i] == goal_piece or unpacked_state[1][i] == goal_piece:
                frame_topmost_index = i
                break

        
        goal_topmost_index = None
        for j in range(len(goal[0])):
            if goal[0][j] == goal_piece or goal[1][j] == goal_piece:
                goal_topmost_index = j
                break

        vertical_distance = abs(frame_topmost_index - goal_topmost_index)
        h = ceil(vertical_distance / FlyingBlockPuzzle.num_of_vacant)
        
        goal_side = 0 if FlyingBlockPuzzle.comb_left_flag else 1
        
        if frame_topmost_index < goal_topmost_index:
            columns_in_path = range(frame_topmost_index + 1, goal_topmost_index + FlyingBlockPuzzle.height_of_semm_piece)
        else:
            columns_in_path = range(goal_topmost_index, frame_topmost_index)
        
        unique_pieces = set()
        for col in columns_in_path:
            piece_in_path = unpacked_state[goal_side][col]
            if piece_in_path != 0 and piece_in_path != goal_piece and (piece_in_path not in unique_pieces):
                unique_pieces.add(piece_in_path)

        h += len(unique_pieces)
        
        return h




    def h_G(self, goal):
        h = 0
        goal_piece = 1
        unpacked_state = self.state
        frame_topmost_index = None
        
        for i in range(len(unpacked_state[0])):
            if unpacked_state[0][i] == goal_piece or unpacked_state[1][i] == goal_piece:
                frame_topmost_index = i
                break
        size_of_piece = FlyingBlockPuzzle.size_of_pieces[goal_piece]
        

        goal_topmost_index = None
        for j in range(len(goal[0])):
            if goal[0][j] == goal_piece or goal[1][j] == goal_piece:
                goal_topmost_index = j
                break

        vertical_distance = abs(frame_topmost_index - goal_topmost_index)
        h = ceil(vertical_distance / FlyingBlockPuzzle.num_of_vacant)
        
        return h
        
    def vertical_distance(self,goal):
        dv=0
        goal_piece = FlyingBlockPuzzle.goal_piece
        unpacked_state = self.state
        frame_pos = [(i, j) for i in range(len(unpacked_state)) for j in range(len(unpacked_state[0])) if unpacked_state[i][j] == FlyingBlockPuzzle.goal_piece]
        goal_pos = [(i, j) for i in range(len(goal)) for j in range(len(goal[0])) if goal[i][j] == FlyingBlockPuzzle.goal_piece]

        frame_topmost_index = min(frame_pos, key=lambda x: x[1])[1]
        goal_topmost_index = min(goal_pos, key=lambda x: x[1])[1]
        frame_bottommost_index = max(frame_pos, key=lambda x: x[1])[1]
        goal_bottommost_index = max(goal_pos, key=lambda x: x[1])[1]
        is_frame_above_goal = frame_bottommost_index < goal_bottommost_index
        is_goal_above_frame = frame_topmost_index > goal_topmost_index
        frame_column = next(i for i in range(len(unpacked_state[0])) if unpacked_state[0][i] == 1 and unpacked_state[1][i] == 1)
        goal_column = next(j for j in range(len(goal[0])) if goal[0][j] == 1 and goal[1][j] == 1)



        if FlyingBlockPuzzle.state_type == 'E':
            if is_frame_above_goal:
                vertical_distance = abs(frame_bottommost_index - goal_bottommost_index)
            elif is_goal_above_frame:
                vertical_distance = abs(frame_topmost_index - goal_topmost_index)
            else:
                vertical_distance=0

        elif FlyingBlockPuzzle.state_type == 'B' or FlyingBlockPuzzle.state_type == 'C':
            vertical_distance = abs(frame_column - goal_column)

        else:
            dv = abs(frame_topmost_index - goal_topmost_index)

        return dv
    

    def heuristic2(self, goal):

        if FlyingBlockPuzzle.state_type == 'A':
            return -self.depth
        if FlyingBlockPuzzle.state_type == 'B':
            return self.vertical_distance(goal)
        if FlyingBlockPuzzle.state_type == 'C':
            return self.vertical_distance(goal)
        if FlyingBlockPuzzle.state_type == 'D':
            return self.vertical_distance(goal)
        if FlyingBlockPuzzle.state_type == 'E':
            return self.vertical_distance(goal)
        if FlyingBlockPuzzle.state_type == 'F':
            return self.vertical_distance(goal)
        if FlyingBlockPuzzle.state_type == 'G':
            return self.vertical_distance(goal)

        return -self.depth
    
    def __lt__(self, other):
        self_heuristic1 = self.depth + self.heuristic1(FlyingBlockPuzzle.goal)
        other_heuristic1 = other.depth + other.heuristic1(FlyingBlockPuzzle.goal)
        if self_heuristic1 == other_heuristic1:
            self_heuristic2 = self.heuristic2(FlyingBlockPuzzle.goal)
            other_heuristic2 = other.heuristic2(FlyingBlockPuzzle.goal)
            return self_heuristic2 < other_heuristic2
        return self_heuristic1 < other_heuristic1

def print_solution(state, n):
    path = []
    while state is not None:
        path.append(state.state)
        state = state.parent
    path.reverse()
    for state in path:
        for i in range(n):
            print(state[0][i], state[1][i])
        print()
        
        
def check_memory_limit(limit_mb=10240):
    """Check if memory usage exceeds the limit in MB."""
    process = psutil.Process()
    memory_usage = process.memory_info().rss / (1024 ** 2) 
    if memory_usage > limit_mb:
        print(f"Memory limit exceeded: {memory_usage:.2f} MB used.")
        return True
    return False


def A_star(root, goal, n, memory_limit=10240):
    open_list = []
    visited = set()
    num=FlyingBlockPuzzle.num
    num[0]=0
    root.depth = 0
    root_cost = root.heuristic1(goal)
    heapq.heappush(open_list, (root_cost, root))

    current_depth = -1
    s_open_nodes = 1
    
    while open_list:
        if check_memory_limit(memory_limit):
            raise MemoryError("Memory usage exceeded the limit.")
        _time = time.time()
        if(_time - FlyingBlockPuzzle.start_time > 1740):
            break
        _, state = heapq.heappop(open_list)
        FlyingBlockPuzzle.expanded_node_count += 1
        if state.depth > current_depth:
            print(f"searching in depth {state.depth}")
            current_depth = state.depth
            FlyingBlockPuzzle.depth_nodes[current_depth] = s_open_nodes
            s_open_nodes = 0
        if(state.depth in num.keys()):
            num[state.depth]+=1
        else:
            num[state.depth]=1

        if state.is_goal(goal):
            return state

        neighbors = state.get_neighbors()
        for ng in neighbors:
            state_tuple = tuple(map(tuple, ng.state))
            if not FlyingBlockPuzzle.consistent or state_tuple not in visited:
                if FlyingBlockPuzzle.consistent:
                    visited.add(state_tuple)
                FlyingBlockPuzzle.opened_node_count += 1
                s_open_nodes += 1
                ng.parent = state
                ng.depth = state.depth + 1
                cost = ng.depth + ng.heuristic1(goal)
                heapq.heappush(open_list, (cost, ng))
    

    return None

class FlyingBlockPuzzle:
    goal = []
    goal_piece = -1
    size_of_pieces = [-1]
    height_of_semm_piece = 0
    mask=[[],[]]
    num_of_pieces = 0
    expanded_node_count = 1
    opened_node_count = 1
    num_of_vacant = 0
    state_type = None
    goal_piece_size = 0
    consistent = True
    N=0
    start_time=0
    num = dict()
    depth_nodes = {}
    comb_right_flag=False
    comb_left_flag=False
    @staticmethod
    def main():
        FlyingBlockPuzzle.num_of_pieces = 0

        n = int(input("enter the height of the frame(n): "))
        FlyingBlockPuzzle.N=n
        init_board = [[0] * n for _ in range(2)]
        FlyingBlockPuzzle.goal = [[0] * n for _ in range(2)]

        print("enter the frame:")
        size_of_semm=0
        for i in range(n):
            s1 = input()
            ind_space_s1 = s1.index(' ')
            init_board[0][i] = int(s1[0:ind_space_s1])
            init_board[1][i] = int(s1[ind_space_s1 + 1 :])
            if init_board[0][i] > FlyingBlockPuzzle.num_of_pieces:
                FlyingBlockPuzzle.num_of_pieces = init_board[0][i]
            if init_board[1][i] > FlyingBlockPuzzle.num_of_pieces:
                FlyingBlockPuzzle.num_of_pieces = init_board[1][i]
            if init_board[0][i] == 0:
                FlyingBlockPuzzle.num_of_vacant += 1
            if init_board[1][i] == 0:
                FlyingBlockPuzzle.num_of_vacant += 1
            if init_board[0][i]==1:
                size_of_semm+=1
            if init_board[1][i]==1:
                size_of_semm+=1
        FlyingBlockPuzzle.size_of_pieces.append(size_of_semm)

        print("enter the goal:")
        for i in range(n):
            s2 = input()
            ind_space_s2 = s2.index(' ')
            FlyingBlockPuzzle.goal[0][i] = int(s2[0:ind_space_s2])
            FlyingBlockPuzzle.goal[1][i] = int(s2[ind_space_s2 + 1:])
            if int(s2[0:ind_space_s2]) != 0:
                FlyingBlockPuzzle.goal_piece = int(s2[0:ind_space_s2])
                FlyingBlockPuzzle.goal_piece_size += 1
            if int(s2[ind_space_s2 + 1:]) != 0:
                FlyingBlockPuzzle.goal_piece = int(s2[ind_space_s2 + 1:])
                FlyingBlockPuzzle.goal_piece_size += 1
        for i in range(2, FlyingBlockPuzzle.num_of_pieces + 1):
            flag = False
            start_pos = -1
            for j in range(n):
                if init_board[0][j] == i:
                    flag = True
                    start_pos = j
                    break
            if flag:
                if init_board[1][start_pos] == i:
                    FlyingBlockPuzzle.size_of_pieces.append(2)
                else:
                    size = 1
                    while start_pos + size < n and init_board[0][start_pos + size] == i:
                        size += 1
                    FlyingBlockPuzzle.size_of_pieces.append(size)
            else:
                start_pos = -1
                for j in range(n):
                    if init_board[1][j] == i:
                        start_pos = j
                        break
                size = 1
                while start_pos + size < n and init_board[1][start_pos + size] == i:
                    size += 1
                FlyingBlockPuzzle.size_of_pieces.append(size)



        

        flag=False
        start_pos=-1
        for i in range(n):
            if init_board[0][i]==1 or init_board[1][i]==1:
                FlyingBlockPuzzle.height_of_semm_piece+=1
                if not flag:
                    flag=True
                    start_pos=i

        for i in range(FlyingBlockPuzzle.height_of_semm_piece):
            FlyingBlockPuzzle.mask[0].append(0)
            FlyingBlockPuzzle.mask[1].append(0)

        



        z=0
        for i in range(start_pos, start_pos+FlyingBlockPuzzle.height_of_semm_piece):
            if init_board[0][i]==1:
                FlyingBlockPuzzle.mask[0][z]=1
            else:
                FlyingBlockPuzzle.mask[0][z]=-1

            if init_board[1][i]==1:
                FlyingBlockPuzzle.mask[1][z]=1
            else:
                FlyingBlockPuzzle.mask[1][z]=-1

            z+=1

        is_comb=False
        num_of_indents=0
        free_spaces=0
        if FlyingBlockPuzzle.goal_piece == 1 and size_of_semm > 3:
            FlyingBlockPuzzle.comb_right_flag=True
            FlyingBlockPuzzle.comb_left_flag=True
            for i in range(FlyingBlockPuzzle.height_of_semm_piece):
                if FlyingBlockPuzzle.mask[0][i]==-1:
                    FlyingBlockPuzzle.comb_left_flag=False
                if FlyingBlockPuzzle.mask[1][i]==-1:
                    FlyingBlockPuzzle.comb_right_flag=False
            if FlyingBlockPuzzle.comb_left_flag or FlyingBlockPuzzle.comb_right_flag:
                is_comb = True
            if is_comb:
                for i in range(FlyingBlockPuzzle.height_of_semm_piece):
                    if FlyingBlockPuzzle.comb_left_flag:
                        if FlyingBlockPuzzle.mask[1][i]==1:
                            num_of_indents+=1
                    if FlyingBlockPuzzle.comb_right_flag:
                        if FlyingBlockPuzzle.mask[0][i]==1:
                            num_of_indents+=1
                free_spaces=FlyingBlockPuzzle.height_of_semm_piece-num_of_indents
                    




        if FlyingBlockPuzzle.num_of_vacant >= FlyingBlockPuzzle.goal_piece_size:
            FlyingBlockPuzzle.state_type = 'A'
        else:
            if FlyingBlockPuzzle.goal_piece == 1:
                if size_of_semm == 3:
                    if FlyingBlockPuzzle.num_of_vacant==2:
                        FlyingBlockPuzzle.state_type = 'B'
                    else:
                        FlyingBlockPuzzle.state_type = 'C'
                else:
                    if is_comb and free_spaces>FlyingBlockPuzzle.num_of_vacant:
                        FlyingBlockPuzzle.state_type = 'F'
                    else:
                        FlyingBlockPuzzle.state_type = 'G'
                    
            else:
                if FlyingBlockPuzzle.goal_piece_size > 2:
                    FlyingBlockPuzzle.state_type = 'D'
                    
                else:
                    FlyingBlockPuzzle.state_type = 'E'
                    
        print(FlyingBlockPuzzle.state_type)
                    

        
    
        root = State(init_board)
        root.depth = 0
        FlyingBlockPuzzle.start_time = time.time()
        print(root.heuristic1(FlyingBlockPuzzle.goal))
        try:
            goal_state = A_star(root, FlyingBlockPuzzle.goal, n, memory_limit=10240)
        except:
            print('memory limit')
            print('Opend nodes in each state:')
            print(FlyingBlockPuzzle.depth_nodes)
            print(f"Opened states: {FlyingBlockPuzzle.opened_node_count}")
        finally:
            end_time = time.time()
            num=FlyingBlockPuzzle.num
            for key, value in num.items() :
                    print (key, value)
            sum=0
            for key, value in num.items() :
                if key != 0:
                    print('average b in layer ',key,'=',value/num[key-1])
                    sum+=(value/num[key-1])
            print('total average b is ', sum/len(num.keys()))
            if goal_state is None:
                print("No solution found.")
            else:
                print(f"the best solution is in depth: {goal_state.depth}")
                print("solution:")
                print_solution(goal_state, n)
            print(f"Search time: {end_time - FlyingBlockPuzzle.start_time} seconds")
            print(f"Expanded states: {FlyingBlockPuzzle.expanded_node_count}")
            print(f"Opened states: {FlyingBlockPuzzle.opened_node_count}")
            print('Opend nodes in each state:')
            print(FlyingBlockPuzzle.depth_nodes)
            print(f"the best solution is in depth: {goal_state.depth}")
        

if __name__ == "__main__":
    FlyingBlockPuzzle.main()
